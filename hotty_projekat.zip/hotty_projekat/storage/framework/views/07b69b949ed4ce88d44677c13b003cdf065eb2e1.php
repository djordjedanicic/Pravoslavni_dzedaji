<html>
    <head>
        <meta name="author" content="Djordje Danicic 2017/0692">
    </head>
    <body>
        <table border = "0px" width = "100%">
        <form action = '/restoran/<?php echo e($restoran->id); ?>' class="form-horizontal" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "right" width = "50%"><img src = "/slike/logo4.png" height = "100" width = "100" ></th> 
            </tr>
            <tr>
                <th width = "100%" colspan = "2">
                    <br><hr><br>
                </th>
            </tr>
            <tr>
            <th align = "center">
                Telefon: 
            </th>
            <th>
                <input type="text" name="telefon" size="30" value="<?php echo e(old('telefon') ?? $restoran->profil_restorana->telefon); ?>" >
                        <?php if($errors->has('telefon')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('telefon')); ?></strong>
                        </span>
                        <?php endif; ?>
            </th>
        </tr>
        <tr>
            <th align = "center">
                Lokacija:
            </th>
            <th>
                <input type="text" name="lokacija" size="30" value="<?php echo e(old('lokacija') ?? $restoran->profil_restorana->lokacija); ?>" >
                        <?php if($errors->has('lokacija')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('lokacija')); ?></strong>
                        </span>
                        <?php endif; ?>
                
            </th>
        </tr>
        <tr>
            <th align = "center">
                Opstina:
            </th>
            <th class="box">
                <select name="opstina" id="opstina" value="<?php echo e(old('opstina') ?? $restoran->profil_restorana->opstina); ?>">
                <option><?php echo e(old('opstina') ?? $restoran->profil_restorana->opstina); ?> </option>
                    <option>Novi Beograd</option>
                    <option>Stari grad</option>
                    <option>Vracar</option>
                    <option>Vozdovac</option>
                </select>
                
            </th>
        </tr>
        <tr>
            <th align = "center">Tip Kuhinje: </th>
            <th class="box">
                <select name="tip" id="tip" value="<?php echo e(old('tip') ?? $restoran->profil_restorana->tip); ?>">
                <option><?php echo e(old('tip') ?? $restoran->profil_restorana->tip); ?></option>
                    <option>Azijska</option>
                    <option>Italijanska</option>
                    <option>Brza Hrana</option>
                    <option>Meksicka</option>
                </select>
                
            </th>
        </tr>
        <tr>
            <th align = "center">
                Vreme od:
            </th>
            <th>
            <input type="time" name="vreme_od" value="<?php echo e(old('vreme_od') ?? $restoran->profil_restorana->vreme_od); ?>" >
                        <?php if($errors->has('vreme_od')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('vreme_od')); ?></strong>
                        </span>
                        <?php endif; ?>
            </th>
        </tr>
        <tr>
            <th align = "center">
                Vreme do:
            </th>
            <th>
            <input type="time" name="vreme_do" value="<?php echo e(old('vreme_do') ?? $restoran->profil_restorana->vreme_do); ?>" >
                        <?php if($errors->has('vreme_do')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('vreme_do')); ?></strong>
                        </span>
                        <?php endif; ?>
            </th>
        </tr>
            <tr>
                <th align="left" colspan="2">
                    <h4>Unesite tekst:</h4>
                </th>
            </tr>
            <tr>
                <th align="left"  valign = "top" colspan="2">
                    <textarea class="form-control<?php echo e($errors->has('opis') ? 'is-invalid' : ''); ?>"
                        name="opis" rows="6" cols="180"><?php echo e(old('opis') ?? $restoran->profil_restorana->opis); ?></textarea>
                        <?php if($errors->has('opis')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('opis')); ?></strong>
                        </span>
                        <?php endif; ?>
                </th>
            </tr>
            <tr>
                    <th align="right">
                        <label for="slika" class="col-md-4 col-form-label">Logo Restorana:</label>
                    </th>
                    <th align="left"  valign = "top">

                        <input type="file" class="form-control-file" multiple="multiple" id="slika" name="slika" >

                        <?php if($errors->has('slika')): ?>
                            <strong><?php echo e($errors->first('slika')); ?></strong>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
            <tr>
                <th colspan="2">
                    <button class="btn btn-primary">Potvrdi</button>
                </th>
            </tr>
        </table>
    </body>
</html><?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/profil/edit.blade.php ENDPATH**/ ?>