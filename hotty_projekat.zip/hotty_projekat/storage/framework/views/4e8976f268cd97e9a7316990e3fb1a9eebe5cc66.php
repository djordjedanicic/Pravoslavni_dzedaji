
<html>
    <head>
        <meta name="author" content="Slobodan Jevtic 2017/0758">
    </head>
    <body>

            <table border = "0px" width = "100%">
                <form action = '/jelo' class="form-horizontal" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <tr>
                    <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                    <th align = "left" width = "50%"><img src = "/slike/logo4.png" height = "100" width = "100" ></th> 
                </tr>
                <tr>
                    <th width = "100%" colspan = "2">
                        <br><hr><br>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Naziv jela:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="naziv" value="<?php echo e(old('naziv')); ?>" >
                        <?php if($errors->has('naziv')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('naziv')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Cena:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="cena" value="<?php echo e(old('cena')); ?>" >
                        <?php if($errors->has('cena')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('cena')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Vrsta jela:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="vrsta" value="<?php echo e(old('vrsta')); ?>" >
                        <?php if($errors->has('vrsta')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('vrsta')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Sastojci:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="sastojci" value="<?php echo e(old('sastojci')); ?>" >
                        <?php if($errors->has('sastojci')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('sastojci')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Gramaza:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="gramaza" value="<?php echo e(old('gramaza')); ?>" >
                        <?php if($errors->has('gramaza')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('gramaza')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <label for="slika" class="col-md-4 col-form-label">Slika:</label>
                    </th>
                    <th align="left"  valign = "top">

                        <input type="file" class="form-control-file" multiple="multiple" id="slika" name="slika" >

                        <?php if($errors->has('slika')): ?>
                            <strong><?php echo e($errors->first('slika')); ?></strong>
                        <?php endif; ?>
                    </th>
                </tr>
                <tr>
                    <th colspan="2">
                        <button class="btn btn-primary">Potvrdi</button>
                    </th>
                </tr>
            </table>
        </form>    
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/jelo/create.blade.php ENDPATH**/ ?>