<html>
    <head>

    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "/slike/logo4.png" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Restoran: <u><?php echo e($restoran->naziv); ?></u> 
                <li class="nav-item dropdown">

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                             <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                </div>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
            <tr>
                <th>
                    <img src = "<?php echo e($restoran->profil_restorana->profileImage()); ?>" width="200" height = "200">
                </th>
                <th align="left">
                    <h4><?php echo e($restoran->profil_restorana->opis); ?></h4>
                </th>
            </tr>
            <tr>
                <th >
                    <a href="/restoran/<?php echo e($restoran->id); ?>/edit">Promeni opis</a>
                </th>
            </tr>
            <th width = "100%" colspan = "2">
                 <br><hr><br>
            </th>
            <tr>
                <th align="center" colspan = "2">
                    <h2>Meni <?php echo e($restoran->naziv); ?></h2>
                </th>
            </tr>
            <tr>
                <th valign = "top">
                    <a href="/jelo/create">Dodaj jelo</a>
                </th>
                <th width = "75%">
                    <table>
                        <?php $__currentLoopData = $restoran->jelo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th>
                                <img src = "/storage/<?php echo e($jelo->slika); ?>" width="200" height = "150">
                            </th>
                            <th align = "left">
                                <ul>
                                    <li>Naziv: <?php echo e($jelo->naziv); ?></li>
                                    <li>Cena: RSD <?php echo e($jelo->cena); ?></li>
                                    <li>Vrsta Jela: <?php echo e($jelo->vrsta); ?></li>
                                    <li>Sastojci: <?php echo e($jelo->sastojci); ?></li>
                                    <li>Kolicina: <?php echo e($jelo->gramaza); ?>g</li>
                                    <li><button type="button">Ukloni jelo</button> <button type="button">Azuriraj</button></li>
                                </ul>
                            </th>
                        </tr>
                        <th width = "100%" colspan = "2">
                            <br><hr><br>
                        </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
                    </table>
                </th>
            </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
        <table border="0px" width = "100%">
            <form action = "<?php echo e(route('komentar.store')); ?>" method="post" enctype="multipart/form-data">
                <tr>
                    <th align="left" colspan="2">
                        <h4>Unesi komentar:</h4>
                    </th>
                </tr>
                <tr>
                    <th align="left"  valign = "top">
                        <input type="text" name="tekst" size="160">
                        <?php if($errors->has('tekst')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('tekst')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </th>
                    <th align="left">
                        <input type="submit" class="btn btn-primary btn-lg" style="width: 100%" name="submit">
                    </th>
                </tr>
                
            </table>
    </body>
</html><?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/profil/index.blade.php ENDPATH**/ ?>