<html>
    <head>

    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "/slike/logo4.png" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Restoran: <u><?php echo e($restoran->naziv); ?></u> 
                <li class="nav-item dropdown">

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                             <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                </div>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
            <tr>
                <th>
                    <img src = "/slike/marukoshi.jpg" width="200" height = "200">
                </th>
                <th align="left">
                    <h4><?php echo e($restoran->profil_restorana->opis); ?></h4>
                </th>
            </tr>
            <tr>
                <th >
                    <button type="button">Promeni logo</button>
                </th>
                <th align="right">
                    <button type="button">Promeni tekst</button>
                </th>
            </tr>
            <th width = "100%" colspan = "2">
                 <br><hr><br>
            </th>
            <tr>
                <th align="center" colspan = "2">
                    <h2>Meni <?php echo e($restoran->naziv); ?></h2>
                </th>
            </tr>
            <tr>
                <th valign = "top">
                    <button type="button">Dodaj jelo</button>
                </th>
                <th width = "75%">
                    <table>
                        <tr>
                            <th>
                                <img src = "/slike/miso_ramen.jpg" width="200" height = "150">
                            </th>
                            <th align = "left">
                                <ul>
                                    <li>Naziv: Miso Ramen</li>
                                    <li>Cena: RSD 750</li>
                                    <li>Vrsta Jela: Supa</li>
                                    <li>Sastojci: Nudle, Đumbir, Mladi Luk, Mungo Pasulj, Tofu Sir, Kukuruz Secerac, Jaje</li>
                                    <li>Kolicina: 400g</li>
                                    <li><button type="button">Ukloni jelo</button> <button type="button">Azuriraj</button></li>
                                </ul>
                            </th>
                        </tr>
                        <th width = "100%" colspan = "2">
                            <br><hr><br>
                        </th>
 
                    </table>
                </th>
            </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
        <table border="0px" width = "100%">
            <tr>
                <th align="left" colspan="2">
                    <h4>Unesi komentar:</h4>
                </th>
            </tr>
            <tr>
                <th align="left"width = "70%">
                    <input type="text" name="kom_tekst_polje" size="200">
                </th>
                <th align="left">
                    <button type="button">Postavi</button>
                </th>
            </tr>
            <table border="0px" width = "100%">
                <tr>
                    <th width = "5%">
                        &nbsp;
                    </th>
                    <th>
                        <table>
                            <tr>
                                <th width = "5%" align="left">
                                    <img src = "/slike/user_logo.png" width="40" height = "40">
                                </th>
                                <th align="left">
                                    <h5>Pera Peric</h5>
                                </th>
                            </tr>
                            <tr align="left">
                                <th colspan="2">
                                    <h5>Restoran je vrh!!! Sve preporuke :)</h5>
                                </th>
                            </tr>
                            <tr>
                                <th colspan="2">
                                    <br><hr><br>
                                </th>
                            </tr>
                        </table>
                    </th>
                </tr>
            </table>
        </table>
    </body>
</html><?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/restoran.blade.php ENDPATH**/ ?>