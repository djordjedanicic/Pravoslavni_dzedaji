<!DOCTYPE html>
<html>
    <head>
        <meta name="author" content="Slobodan Jevtic 2017/0758">
    </head>
	<script>
		function brisanje(){
			alert("da li ste sigurni?");
		}
	</script>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "/slike/logo4.png" height = "100" width = "100"></th> 
                <th align = "right" width = "25%" valign = "top">Restoran: <u><?php echo e($restoran->naziv); ?></u> <button onclick="window.location.href = 'pocetna.html';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
            <tr>
                <th>
                    <img src = "/slike/mc.png" width="200" height = "200">
                </th>
                <th align="left">
                    <h4> Opis restorana </h4>
                </th>
            </tr>
            <tr>
                <th >
                    <button type="button">Promeni logo</button>
                </th>
                <th align="right">
                    <button onclick="window.location.href = 'dodaj_tekst.html';">Promeni tekst</button>
                </th>
            </tr>
            <th width = "100%" colspan = "2">
                 <br><hr><br>
            </th>
            <tr>
                <th align="center" colspan = "2">
                    <h2>Meni <?php echo e($restoran->naziv); ?></h2>
                </th>
            </tr>
            <tr>
                <th valign = "top">
                    <button onclick="window.location.href = '<?php echo e($restoran->id); ?>/jelo/create';">Dodaj jelo</button>
                </th>
                <th width = "75%">
                    <table>
                        <tr>
                            <th>
                                <img src = "/slike/miso_ramen.jpg" width="200" height = "150">
                            </th>
                            <th align = "left">
                                <ul>
                                    <li>Naziv: Miso Ramen</li>
                                    <li>Cena: RSD 750</li>
                                    <li>Vrsta Jela: Supa</li>
                                    <li>Sastojci: Nudle, Đumbir, Mladi Luk, Mungo Pasulj, Tofu Sir, Kukuruz Secerac, Jaje</li>
                                    <li>Kolicina: 400g</li>
                                    <li><button type="button" onclick = "brisanje()">Ukloni jelo</button> <button onclick="window.location.href = 'dodaj_jelo.html';">Azuriraj</button></li>
                                </ul>
                            </th>
                        </tr>
                        <th width = "100%" colspan = "2">
                            <br><hr><br>
                        </th>
                        <tr>
                            <th>
                                <img src = "/slike/soupe_miso.jpg" width="200" height = "150">
                            </th>
                            <th align = "left">
                                <ul>
                                    <li>Naziv: Miso Soup</li>
                                    <li>Cena: RSD 250</li>
                                    <li>Vrsta Jela: Supa</li>
                                    <li>Sastojci: Miso Pasta, Praziluk, Morske Alge, Tofu, Soja Sos, Sesamovo Ulje</li>
                                    <li>Kolicina: 295g</li>
                                    <li><button type="button" onclick = "brisanje()">Ukloni jelo</button> <button onclick="window.location.href = 'dodaj_jelo.html';">Azuriraj</button></li>
                                </ul>
                            </th>
                        </tr>
                        <th width = "100%" colspan = "2">
                            <br><hr><br>
                        </th>
                        <tr>
                            <th>
                                <img src = "/slike/leafy_salad.jpg" width="200" height = "150">
                            </th>
                            <th align = "left">
                                <ul>
                                    <li>Naziv: Leafy Salad</li>
                                    <li>Cena: RSD 280</li>
                                    <li>Vrsta Jela: Salata</li>
                                    <li>Sastojci: Mesana Zelena Salata, Ceri Paradajz, Krastavac Sa Slatki Prelivom</li>
                                    <li>Kolicina: 350g</li>
                                    <li><button type="button" onclick = "brisanje()">Ukloni jelo</button> <button onclick="window.location.href = 'dodaj_jelo.html';">Azuriraj</button></li>
                                </ul>
                            </th>
                        </tr>
                        <th width = "100%" colspan = "2">
                            <br><hr><br>
                        </th>
                    </table>
                </th>
            </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
        <table border="0px" width = "100%">
            <tr>
                <th align="left" colspan="2">
                    <h4>Unesi komentar:</h4>
                </th>
            </tr>
            <tr>
                <th align="left"width = "70%">
                    <input type="text" name="kom_tekst_polje" size="200">
                </th>
                <th align="left">
                    <button type="button">Postavi</button>
                </th>
            </tr>
            <table border="0px" width = "100%">
                <tr>
                    <th width = "5%">
                        &nbsp;
                    </th>
                    <th>
                        <table>
                            <tr>
                                <th width = "5%" align="left">
                                    <img src = "/slike/user_logo.png" width="40" height = "40">
                                </th>
                                <th align="left">
                                    <h5>Pera Peric</h5>
                                </th>
                            </tr>
                            <tr align="left">
                                <th colspan="2">
                                    <h5>Restoran je vrh!!! Sve preporuke :)</h5>
                                </th>
                            </tr>
                            <tr>
                                <th colspan="2">
                                    <br><hr><br>
                                </th>
                            </tr>
                            <tr>
                                <th width = "5%" align="left">
                                    <img src = "/slike/user_logo.png" width="40" height = "40">
                                </th>
                                <th align="left">
                                    <h5>Jovan Nikolic</h5>
                                </th>
                            </tr>
                            <tr align="left">
                                <th colspan="2">
                                    <h5>Nije lose, mada sam ocekivao mnoogo vise.</h5>
                                </th>
                            </tr>
                            <tr>
                                <th colspan="2">
                                    <br><hr><br>
                                </th>
                            </tr>
                        </table>
                    </th>
                </tr>
            </table>
        </table>
    </body>
</html><?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/profili_restorana/restoran_home.blade.php ENDPATH**/ ?>