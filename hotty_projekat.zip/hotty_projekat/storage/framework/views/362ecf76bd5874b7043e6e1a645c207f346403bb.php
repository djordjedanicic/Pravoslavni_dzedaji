<html>
<head>
    <meta name="author" content="Djordje Danicic 2017/0692">
</head>
<body>
    <table border = "0px" width = "100%">
        <tr>
            <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
            <th align = "left" width = "50%"><img src = "slike/logo4.png" height = "100" width = "100" ></th> 
            
        </tr>
        <tr>
            <th width = "100%" colspan = "2">
                <br><hr><br>
            </th>
        </tr>
    </table>
    <table border = "0px">
        <tr>
            <th align = "left">
                Naziv: 
            </th>
            <th>
                <input type="text" name="ime" size="30">
            </th>
        </tr>
        <tr>
            <th align = "left">
                Telefon: 
            </th>
            <th>
                <input type="text" name="telefon" size="30">
            </th>
        </tr>
        <tr>
            <th align = "left">
                Lokacija:
            </th>
            <th>
                <input type="text" name="telefon" size="30">
            </th>
        </tr>
        <tr>
            <th align = "left">Tip Kuhinje: </th>
            <th>
                <input type = "radio" name = "tip">&nbsp;Azijska
                <input type = "radio" name = "tip">&nbsp;Italijanska
                <input type = "radio" name = "tip">&nbsp;Brza Hrana
            </th>
        </tr>
        <tr>
            <th align = "left">
                Vreme od:
            </th>
            <th>
                <input type="time" name="sifraPon" >
            </th>
        </tr>
        <tr>
            <th align = "left">
                Vreme do:
            </th>
            <th>
                <input type="time" name="sifraPon">
            </th>
        </tr>
        <tr>
            <th align = "left">
                Mail: 
            </th>
            <th>
                <input type="text" name="mail" size="30">
            </th>
        </tr>
        <tr>
            <th align = "left">
                Sifra: 
            </th>
            <th>
                <input type="password" name="sifra" size="30">
            </th>
        </tr>
        <tr>
            <th align = "left">
                Ponovi sifru: 
            </th>
            <th>
                <input type="password" name="sifraPon" size="30">
            </th>
        </tr>
       
        <tr>
            <th colspan = "2">
                <br>
                <input type = "button" value = "Registruj Se">
            </th>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/register_restorana.blade.php ENDPATH**/ ?>