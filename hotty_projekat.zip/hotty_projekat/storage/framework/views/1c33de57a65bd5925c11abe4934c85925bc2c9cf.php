<html>
    <head>
        <meta name="author" content="Slobodan Jevtic 2017/0758">
    </head>
    <body>
        <form action = '/jelo' encrypt="multipart/form-data" method = "post">
            <?php echo csrf_field(); ?>

            <table border = "0px" width = "100%">
                <tr>
                    <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                    <th align = "left" width = "50%"><img src = "/slike/logo4.png" height = "100" width = "100" ></th> 
                </tr>
                <tr>
                    <th width = "100%" colspan = "2">
                        <br><hr><br>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Naziv jela:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="naziv" value="<?php echo e(old('naziv')); ?>" >
                        <?php $__errorArgs = ['naziv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Cena:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="cena" value="<?php echo e(old('cena')); ?>" >
                        <?php $__errorArgs = ['cena'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Vrsta jela:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="vrsta" value="<?php echo e(old('vrsta')); ?>" >
                        <?php $__errorArgs = ['vrsta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Sastojci:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="sastojci" value="<?php echo e(old('sastojci')); ?>" >
                        <?php $__errorArgs = ['sastojci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <h4>Gramaza:</h4>
                    </th>
                    <th align="left"  valign = "top">
                        <input type="text" name="gramaza" value="<?php echo e(old('gramaza')); ?>" >
                        <?php $__errorArgs = ['gramaza'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </th>
                </tr>
                <tr>
                    <th align="right">
                        <label for="slika" class="col-md-4 col-form-label">Slika:</label>
                    </th>
                    <th align="left"  valign = "top">

                        <input type="file" class="form-control-file" name="slika" >

                        <?php $__errorArgs = ['slika'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </th>
                </tr>
                <tr>
                    <th colspan="2">
                        <button class="btn btn-primary">Potvrdi</button>
                    </th>
                </tr>
            </table>
        </form>    
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\hotty_projekat\resources\views/jela/create.blade.php ENDPATH**/ ?>