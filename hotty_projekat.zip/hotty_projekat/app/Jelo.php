<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jelo extends Model
{
    public function restoran()
    {
        return $this->belongsTo(Restoran::class);
    }
}
