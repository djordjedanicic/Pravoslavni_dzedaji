<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Korisnik extends Model
{
    public function porudzbina() 
    {
        return $this->hasMany(Porudzbina::class)->orderBy('created_at', 'DESC');
    }
}
