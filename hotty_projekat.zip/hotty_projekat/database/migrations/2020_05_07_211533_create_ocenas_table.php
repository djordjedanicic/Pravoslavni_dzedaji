<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOcenasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ocena', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('idKor');
            $table->unsignedBigInteger('idRes');
            $table->integer('vrednost');
            $table->timestamps();

            $table->index('idRes');
            $table->index('idKor');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ocena');
    }
}
