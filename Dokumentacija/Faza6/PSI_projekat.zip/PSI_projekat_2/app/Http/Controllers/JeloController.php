<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jelo;

class JeloController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function prikazDodajJelo(){
        if(session()->has('restoran'))
            return view('funRegRest.dodaj_jelo');
        return back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $jelo = new Jelo;
        $this->validate($request, [
            'naziv' => 'required',
            'cena' => 'required',
            'vrsta' => 'required',
            'sastojci' => 'required',
            'gramaza' => 'required',
            'slika' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        $jelo->id_rest = session('restoran');
        $jelo->naziv = $request->naziv;
        $jelo->cena = $request->cena;
        $jelo->vrsta = $request->vrsta;
        $jelo->sastojci = $request->sastojci;
        $jelo->gramaza = $request->gramaza;
        $imageName = time().'.'.$request->slika->extension();  
        $request->slika->move(public_path('images'), $imageName);
        $jelo->slika = $imageName;
        $jelo->save();
        return redirect()->route('pocetna_restoran.show',session('restoran'));
    }


    public function bris_azur_jela(Request $request){
        if(session()->has('restoran')){
            if($request->has('ukloni_jelo')){
                $jelo = Jelo::find($request->ukloni_jelo);
                $jelo->delete();
                return redirect()->route('pocetna_restoran.show',session('restoran'));
            }else{
                if($request->has('azuriraj_jelo')){
                    $jelo = Jelo::find($request->azuriraj_jelo);
                    return view('funRegRest.azuriraj_jelo', compact('jelo'));
                }
            }
            
        }else return back();
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if(session()->has('restoran')){
            $jelo = Jelo::find($id);
            $jelo->fill($request->all());
            if($request->hasFile('slika')){
                $this->validate($request, [
                    'slika' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
                ]);
                $imageName = time().'.'.$request->slika->extension();  
                $request->slika->move(public_path('images'), $imageName);
                $jelo->slika = $imageName;
            }
            $jelo->save();
            return redirect()->route('pocetna_restoran.show',session('restoran'));
        } 
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
