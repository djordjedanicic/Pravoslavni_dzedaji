<html>
    <head>
        <meta name="author" content="Djordje Danicic 2017/0692">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">  
                <?php if(session()->has('korisnik')): ?>
                    <?php echo e($korisnik->ime); ?> <?php echo e($korisnik->prezime); ?> <br> Bodovi: <?php echo e($korisnik->bodovi); ?> <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button>
                <?php else: ?>
                    <button onclick="window.location.href = '/reg_log';">Registruj/Uloguj se</button>
                <?php endif; ?>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan="3">
                    <?php if(session()->has('korisnik')): ?>
                        <button onclick="window.location.href = '<?php echo e(URL::route('pocetna.show',$korisnik->id)); ?>';">Pocetna</button>
                        <button type="button" onclick="window.location.href ='/mojeNarudz';">Moje Narudzbine</button>
                    <?php else: ?>
                        <button onclick="window.location.href = '/pocetnaGost';">Pocetna</button>
                        <button type="button" onclick="nijeMoguce()">Moje Narudzbine</button>
                    <?php endif; ?>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <center>
            <table width = "50%" border = "0px">
                <tr>
                    <th colspan = "3">
                        <h3>Moje narudzbine</h3>
                    </th>
                </tr>
                <tr>
                    <th colspan = "3"><br><hr><br></th>
                </tr>
                <tr>
                    <th width = "40%">
                        Naziv
                    </th>
                    <th width = "20%">
                        Kolicina
                    </th>
                    <th width = "40%">
                        Cena
                    </th>
                </tr>
                <?php if(session()->has('porudzbina')): ?>
                    <?php $__currentLoopData = $porucena_jela; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poruceno_jelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th width = "40%">
                                <?php echo e($poruceno_jelo->naziv_jela); ?>

                            </th>
                            <th width = "20%">
                                x<?php echo e($poruceno_jelo->kvantitet); ?>

                            </th>
                            <th width = "40%">
                                <?php echo e($poruceno_jelo->cena_jela*$poruceno_jelo->kvantitet); ?> rsd
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th colspan = "3"><br> <hr> </th>
                    </tr>
                    <tr>
                        <th colspan = "3">
                            <h3>Ukupna cena</h3>
                        </th>
                    </tr>
                    <form action="/bez_pop" method = 'get'>
                    <?php echo csrf_field(); ?>
                    <tr>
                        <th>
                            Bez popusta
                        </th>
                        <th>
                            <h3 name = 'cena_bez_pop'><?php echo e($porudzbina->cena_bez_pop); ?> rsd</h3>
                        </th>
                        <th>
                            <button type = "submit">Poruci</button>
                        </th>
                    </tr>
                    </form>
                    <form action = "/sa_pop"  method = 'get'>
                    <?php echo csrf_field(); ?>
                    <tr>
                        <th>
                            Sa popustom
                        </th>
                        <th>
                            <h3 name = 'cena_sa_pop'><?php echo e($porudzbina->cena_sa_pop); ?> rsd</h3>
                        </th>
                        <th>
                            <button type = "submit">Poruci</button>
                        </th>
                    </tr>
                    </form>
                <?php endif; ?>
            </table>
        </center>

    </body>
</html><?php /**PATH C:\xampp\htdocs\PSI_projekat_2\resources\views/stranice/moje_narudzbine.blade.php ENDPATH**/ ?>