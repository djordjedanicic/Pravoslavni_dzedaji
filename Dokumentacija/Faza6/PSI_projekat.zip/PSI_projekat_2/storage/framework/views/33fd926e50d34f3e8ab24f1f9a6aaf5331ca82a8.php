
<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 2017/0698">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">  
                <?php if(session()->has('korisnik')): ?>
                    <?php echo e($korisnik->ime); ?> <?php echo e($korisnik->prezime); ?> <br> Bodovi: <?php echo e($korisnik->bodovi); ?> <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button>
                <?php else: ?>
                    <button onclick="window.location.href = '/reg_log';">Registruj/Uloguj se</button>
                <?php endif; ?>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan="3">
                    <?php if(session()->has('korisnik')): ?>
                        <button onclick="window.location.href = '<?php echo e(URL::route('pocetna.show',$korisnik->id)); ?>';">Pocetna</button>
                        <button type="button" onclick="window.location.href ='/mojeNarudz';">Moje Narudzbine</button>
                    <?php else: ?>
                        <button onclick="window.location.href = '/pocetnaGost';">Pocetna</button>
                        <button type="button" onclick="nijeMoguce()">Moje Narudzbine</button>
                    <?php endif; ?>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
                    <tr>
                        <th width = "30%">
                        <img src = '/images/<?php echo e($restoran->slika); ?>'  width="200" height = "200">
                        </th>
                        <th align="left">
                            <h4>
                                <?php echo e($restoran->opis); ?>

                            </h4>
                        </th>
                    </tr>
                    <tr>
                        <th colspan = "2">
                            <br><hr><br>
                        </th>
                    </tr>
                    <tr>
                        <form action="<?php echo e(URL::route('oceni.restoran',$restoran->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <th colspan = "2" align = "right"> 
                                <input type="radio" name="ocena" value="1" id="ocena_1"><label for="ocena_1">1</label>
                                <input type="radio" name="ocena" value="2" id="ocena_2"><label for="ocena_2">2</label>
                                <input type="radio" name="ocena" value="3" id="ocena_3"><label for="ocena_3">3</label>
                                <input type="radio" name="ocena" value="4" id="ocena_4"><label for="ocena_4">4</label>
                                <input type="radio" name="ocena" value="5" id="ocena_5"><label for="ocena_5">5</label>
                                &nbsp;
                                <?php if(session()->has('korisnik')): ?>
                                    <input type="submit" value="Oceni">
                                <?php else: ?>
                                    <input type="button" value="Oceni" onclick="nijeMoguce()">
                                <?php endif; ?>
                            </th>
                        </form>
                    </tr>
                    <tr>
                        <th align="center" colspan = "2">
                            <h2>Meni <?php echo e($restoran->naziv); ?></h2>
                        </th>
                    </tr>
                    <tr>
                        <th>&nbsp;</th>
                        <th width = "75%">
                            <form  method="get" action="/dodaj_u_korpu" name="forma_meni">
                            <?php echo csrf_field(); ?>
                            <table>
                                <?php $__currentLoopData = $jela; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th>
                                        <img src = '/images/<?php echo e($jelo->slika); ?>' width='200' height = '200'>
                                    </th>
                                    <th align = 'left'>
                                        <ul style="list-style-type:none;">
                                            <li>Naziv: <?php echo e($jelo->naziv); ?></li>
                                            <li>Cena: RSD <?php echo e($jelo->cena); ?></li>
                                            <li>Vrsta Jela: <?php echo e($jelo->vrsta); ?></li>
                                            <li>Sastojci: <?php echo e($jelo->sastojci); ?></li>
                                            <li>Kolicina: <?php echo e($jelo->gramaza); ?>g</li>
                                            <br>
                                            <li><button type="submit" name = "id_jela" value = "<?php echo e($jelo->id); ?>">Dodaj u korpu</button></li>
                                        </ul>
                                    </th>
                                </tr>
                                <tr>
                                    <th width = '100%' colspan = '2'>
                                        <br><hr><br>
                                    </th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            </form>
                        </th>
                    </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
        <table border="0px" width = "100%">
            <form action="<?php echo e(URL::route('postavi.komentar',$restoran->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <tr>
                <th align="left" colspan="2">
                    <h4>Unesi komentar:</h4>
                </th>
            </tr>
            <tr>
                <th align="left"width = "70%">
                    <input type="text" name="tekst_kom" size="200">
                </th>
                <th align="left">
                    <?php if(session()->has('korisnik')): ?>
                        <input type="submit" value="Postavi">
                    <?php else: ?>
                        <input type="button" value="Postavi" onclick="nijeMoguce()">
                    <?php endif; ?>
                </th>
            </tr>
            </form>
            <table border="0px" width = "100%">
                <tr>
                    <th width = "5%">
                        &nbsp;
                    </th>
                    <th>
                        <table>
                            <?php $__currentLoopData = $komentari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th width = "5%" align="left">
                                        <img src = "slike/user_logo.png" width="40" height = "40">
                                    </th>
                                    <th align="left">
                                        <h5><?php echo e($kom->ime); ?> <?php echo e($kom->prezime); ?></h5>
                                    </th>
                                </tr>
                                <tr align="left">
                                    <th colspan="2">
                                        <h5><?php echo e($kom->tekst); ?></h5>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="2">
                                        <br><hr><br>
                                    </th>
                                </tr>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </th>
                </tr>
            </table>
        </table>
    </body>
</html>
<script>
    function nijeMoguce(){
        alert("Niste ulogovani, nemate pristup ovoj opciji");
    }
</script><?php /**PATH C:\xampp\htdocs\PSI_projekat_2\resources\views/stranice/meni_restorana.blade.php ENDPATH**/ ?>