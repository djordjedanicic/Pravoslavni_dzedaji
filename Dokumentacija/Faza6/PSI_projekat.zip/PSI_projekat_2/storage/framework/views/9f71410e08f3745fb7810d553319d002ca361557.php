<html>
    <head>
        <meta name="author" content="Slobodan Jevtic 2017/0758">
    </head>
	<script>
		function brisanje(){
			alert("da li ste sigurni?");
		}
	</script>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src =  "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Restoran: <u><?php echo e($restoran->naziv); ?></u> <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
            <tr>
                <th>
                    <img src = "/images/<?php echo e($restoran->slika); ?>" width="200" height = "200">
                </th>
                <th align="left">
                    <h4>
                        <?php echo e($restoran->opis); ?>

                    </h4>
                </th>
            </tr>
            <tr>
                <th >
                <button onclick="window.location.href ='/dodaj_sliku';">Promeni logo</button>
                </th>
                <th align="right">
                    <button onclick="window.location.href ='/dodaj_tekst';">Promeni tekst</button>
                </th>
            </tr>
            <th width = "100%" colspan = "2">
                 <br><hr><br>
            </th>
            <tr>
                <th align="center" colspan = "2">
                    <h2>Meni <?php echo e($restoran->naziv); ?></h2>
                </th>
            </tr>
            <tr>
                <th valign = "top">
                    <button onclick="window.location.href ='/forma_dodaj_jelo';">Dodaj jelo</button>
                </th>
                <th width = "75%">
                    <table>
                         <?php $__currentLoopData = $jela; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="/brisanje_azuriranje_jela" method='get'>
                                <tr>
                                    <th>
                                        <img src= '/images/<?php echo e($jelo->slika); ?>' width='200' height = '200'>
                                    </th>
                                    <th align = 'left'>
                                        <ul style="list-style-type:none;">
                                            <li>Naziv: <?php echo e($jelo->naziv); ?></li>
                                            <li>Cena: RSD <?php echo e($jelo->cena); ?></li>
                                            <li>Vrsta Jela: <?php echo e($jelo->vrsta); ?></li>
                                            <li>Sastojci: <?php echo e($jelo->sastojci); ?></li>
                                            <li>Kolicina:<?php echo e($jelo->gramaza); ?>g</li>
                                            <br>
                                            <li><button name='ukloni_jelo' type='submit' value = '<?php echo e($jelo->id); ?>'>Ukloni jelo</button> <button name='azuriraj_jelo' type='submit' value = '<?php echo e($jelo->id); ?>'>Azuriraj</button></li>
                                        </ul>
                                    </th>
                                </tr>
                                <tr>
                                    <th width = '100%' colspan = '2'>
                                        <br><hr><br>
                                    </th>
                                </tr>
                                </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </th>
            </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
            <table border="0px" width = "100%">
                <tr>
                    <th width = "5%">
                        &nbsp;
                    </th>
                    <th>
                        <table>
                            <?php $__currentLoopData = $komentari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th width = "5%" align="left">
                                        <img src = "slike/user_logo.png" width="40" height = "40">
                                    </th>
                                    <th align="left">
                                        <h5><?php echo e($kom->ime); ?> <?php echo e($kom->prezime); ?></h5>
                                    </th>
                                </tr>
                                <tr align="left">
                                    <th colspan="2">
                                        <h5><?php echo e($kom->tekst); ?></h5>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="2">
                                        <br><hr><br>
                                    </th>
                                </tr>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </th>
                </tr>
        </table>
    </body>
</html><?php /**PATH C:\xampp\htdocs\PSI_projekat_2\resources\views/stranice/restoran.blade.php ENDPATH**/ ?>