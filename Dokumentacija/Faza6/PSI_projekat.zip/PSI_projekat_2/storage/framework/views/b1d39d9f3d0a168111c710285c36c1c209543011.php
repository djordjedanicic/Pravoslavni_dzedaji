
<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 2017/0698">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">  
                <?php if(session()->has('korisnik')): ?>
                    <?php echo e($korisnik->ime); ?> <?php echo e($korisnik->prezime); ?> <br> Bodovi: <?php echo e($korisnik->bodovi); ?> <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button>
                <?php else: ?>
                    <button onclick="window.location.href = '/reg_log';">Registruj/Uloguj se</button>
                <?php endif; ?>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan="3">
                    <?php if(session()->has('korisnik')): ?>
                        <button onclick="window.location.href = '<?php echo e(URL::route('pocetna.show',$korisnik->id)); ?>';">Pocetna</button>
                        <button type="button" onclick="window.location.href ='/mojeNarudz';">Moje Narudzbine</button>
                    <?php else: ?>
                        <button onclick="window.location.href = '/pocetnaGost';">Pocetna</button>
                        <button type="button" onclick="nijeMoguce()">Moje Narudzbine</button>
                    <?php endif; ?>
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table width = "100%" border = "0px">
            <tr>
                <th colspan = "2" align = "left">Filteri:</th>
            </tr>
            <tr>
                <form method="GET" action="<?php echo e(URL::route('pocetna.filter.show')); ?>" name="forma_filter">
                <?php echo csrf_field(); ?>
                    <th align = "left" width = "15%" valign="top">
                    <i>Lokacija</i><br>
                        <ul>
                            <li>
                                <input type="checkbox" id="noviBeograd" name="opstina[]" value="Novi Beograd">
                                <label for="noviBeograd"> Novi Beograd</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="stariGrad" name="opstina[]" value="Stari grad">
                                <label for="stariGrad"> Stari grad</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="vracar" name="opstina[]" value="Vracar">
                                <label for="vracar"> Vracar</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="vozdovac" name="opstina[]" value="Vozdovac">
                                <label for="vozdovac"> Vozdovac</label><br>
                            </li>
                        </ul><br>
                        <i>Tip Kuhinje</i><br>
                        <ul>
                            <li>
                                <input type="checkbox" id="azijska" name="hrana[]" value="Azijska">
                                <label for="azijska"> Azijska</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="italijanska" name="hrana[]" value="Italijanska">
                                <label for="italijanska"> Italijanska</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="brzaHrana" name="hrana[]" value="Brza hrana">
                                <label for="brzaHrana"> Brza hrana</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="meksicka" name="hrana[]" value="Meksicka">
                                <label for="meksicka"> Meksicka</label><br>
                            </li>
                        </ul><br>
                    <input type="submit" value="Potvrdi">
                    </th>
                </form>
                <th align = "left" width = "15%" valign="top">
                    &nbsp;
                </th>
                <th width = "70%">
                    <form  method="get" action="/menicontroller" name="forma_meni">
                    <?php echo csrf_field(); ?>
                    <table>
                        <?php $__currentLoopData = $restorani; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th>
                                    <img src= '/images/<?php echo e($element->slika); ?>' width='200' height = '200'>
                                </th>
                                <th align = 'left'>
                                    <ul>
                                        <li>Naziv: <?php echo e($element->naziv); ?></li>
                                        <li>Adresa: <?php echo e($element->lokacija); ?></li>
                                        <li>Opstina: <?php echo e($element->opstina); ?></li>
                                        <li>Tip Kuhinje: <?php echo e($element->tip); ?></li>
                                        <li>Ocena: <?php echo e($element->ocena); ?></li>
                                        <li>Radno vreme: <?php echo e($element->vreme_od); ?> - <?php echo e($element->vreme_do); ?></li>
                                        <li><button name='id_rest' type='submit' value = '<?php echo e($element->id); ?>'>Meni</button></li>
                                    </ul>
                                </th>
                            </tr>
                            <tr></tr>
                                <th width = '100%' colspan = '2'>
                                    <br><hr><br>
                                </th>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    </form>
                    &nbsp;
                </th>
            </tr>
        </table>
    </body>
</html>
<script>
    function nijeMoguce(){
        alert("Niste ulogovani, nemate pristup ovoj opciji");
    }
</script><?php /**PATH C:\xampp\htdocs\PSI_projekat_2\resources\views/stranice/pocetna.blade.php ENDPATH**/ ?>