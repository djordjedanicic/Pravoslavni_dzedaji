<!DOCTYPE html>
<html>
<head>
    <meta name="author" content="Dimitrije Gucevic 2017/0698">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
    <div class="conteiner">
        <table border = "0px" width = "100%">
            <tr>
                <th width = "50%" style = "text-align:right"><font size = "10">Hotty</font></th>
                <th width = "50%" style = "text-align:left"><img src = "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
            </tr>
            <tr>
                <th width = "100%" colspan = "2">
                    <br><hr><br>
                </th>
            </tr>
        </table>
    </div>
    <?php $__env->startSection('telo'); ?>
    <?php echo $__env->yieldSection(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\PSI_projekat_2\resources\views/registracija/layout.blade.php ENDPATH**/ ?>