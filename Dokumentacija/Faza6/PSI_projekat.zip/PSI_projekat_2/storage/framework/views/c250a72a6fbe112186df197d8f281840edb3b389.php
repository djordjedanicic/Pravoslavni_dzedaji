<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 0698/2017">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Korisnik: <u>ADMIN</u> <br><button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table width = "100%">
            <tr>
                <th align = "left" style = "color:red">Korisnici:</th>
                <th align = "left" style = "color:red">Restorani:</th>
                <th align = "left" style = "color:red">Porudzbine:</th>
            </tr>
                <th width = "100%" colspan = "3">
                    <hr>
                </th>
            <tr>
            <form  method="get" action="/brisanjeKorisnika">
                <th width = "33%" valign = "top">
                    <table width = "100%">
                    <?php $__currentLoopData = $korisnici; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $korisnik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th align = "left" width = "50%">
                        <?php echo e($korisnik->ime); ?> <?php echo e($korisnik->prezime); ?> 
                        </th>
                        <th align = "left" width = "50%">
                        <button name='id_kor' type='submit' value = '<?php echo e($korisnik->id); ?>'>Obrisi</button>
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </th>
            </form>
            <form  method="get" action="/brisanjeRestorana">
                <th width = "33%" valign = "top">
                    <table width = "100%">
                    <?php $__currentLoopData = $restorani; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th align = "left" width = "50%">
                            <?php echo e($restoran->naziv); ?> 
                        </th>
                        <th align = "left" width = "50%">
                            <button name='id_rest' type='submit' value = '<?php echo e($restoran->id); ?>'>Obrisi</button>
                        </th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </th>
            </form>
                <th width = "33%" valign = "top">
                
                    <form action="/ukl_vidi_porudz" method = "get">
                    <table width = "100%">
                    <?php $__currentLoopData = $porudzbine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $porudzbina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th align = "left" >
                                    <?php echo e($porudzbina->adresa); ?> - 
                                <?php if($porudzbina->cena_sa_pop == null): ?>
                                    <?php echo e($porudzbina->cena_bez_pop); ?>rsd
                                <?php else: ?>
                                    <?php echo e($porudzbina->cena_sa_pop); ?>rsd (sa popustom)
                                <?php endif; ?>
                            </th>
                            <th align = "center">
                                <button type = "submit" name = "vidi" value = "<?php echo e($porudzbina->id); ?>">Vidi</button>
                                <button type = "submit" name = "ukloni" value = "<?php echo e($porudzbina->id); ?>">Ukloni</button>
                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    </form>
                </th>
            </tr>
        </table>
       

    </body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\PSI_projekat\resources\views/stranice/admin_pocetna.blade.php ENDPATH**/ ?>