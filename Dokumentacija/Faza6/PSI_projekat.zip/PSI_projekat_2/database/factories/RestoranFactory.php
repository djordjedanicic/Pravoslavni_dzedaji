<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Restoran;
use Faker\Generator as Faker;

$factory->define(Restoran::class, function (Faker $faker) {
    return [
        'naziv' => $faker->firstName,
        'telefon' => $faker->phoneNumber,
        'lokacija' => $faker->address,
        'opstina' => $faker->randomElement(['Novi Beograd', 'Stari grad', 'Vracar', 'Vozdovac']),
        'tip' => $faker->randomElement(['Azijska', 'Italijanska', 'Brza hrana', 'Meksicka']),
        'vreme_od' => "10:00:00",
        'vreme_do' => "22:00:00",
        'email' => $faker->unique()->safeEmail,
        'sifra' => "123",
        'slika' => $faker->randomElement(['1589905772.jpeg', '1589928850.png', '1590010514.png', '1590014126.png', '1590017078.jpeg']),
        'opis' => $faker->paragraph,
        'ocena' => 0,
    ];
});
