<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Jelo;
use Faker\Generator as Faker;

$factory->define(Jelo::class, function (Faker $faker) {
    $vrstaJela = ['Salata', 'Supa', 'Pica', 'Pasta', 'Rostilj', 'Sendvic', 'Susi'];
    $slikaJela = ['1589932587.jpeg', '1589928897.jpeg','1590014834.jpeg', '1590013504.jpeg', '1590020436.jpeg', '1590015231.jpeg', '1590017444.jpeg'];
    $randNum = $faker->numberBetween($min = 0, $max = 6);

    return [
        'id_rest' => $faker->numberBetween($min = 0, $max = 29),
        'naziv' => $vrstaJela[$randNum],
        'cena' => $faker->numberBetween($min = 100, $max = 1000),
        'sastojci' => $faker->paragraph,
        'vrsta' => $vrstaJela[$randNum],
        'gramaza' => $faker->numberBetween($min = 200, $max = 500),
        'slika' => $slikaJela[$randNum],
    ];
});
