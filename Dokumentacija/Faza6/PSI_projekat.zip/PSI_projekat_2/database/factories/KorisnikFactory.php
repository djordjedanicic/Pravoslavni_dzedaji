<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Korisnik;
use Faker\Generator as Faker;

$factory->define(Korisnik::class, function (Faker $faker) {
    return [
        'ime' => $faker->firstName,
        'prezime' => $faker->lastName,
        'adresa' => $faker->address,
        'telefon' => $faker->phoneNumber,
        'pol' => "muski",
        'email' => $faker->unique()->safeEmail,
        'sifra' => "123",
        'bodovi' => 0,
    ];
});
