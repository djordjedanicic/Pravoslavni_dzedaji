<?php

use Illuminate\Database\Seeder;

class JeloSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Jelo::class, 200)->create();
    }
}
