<html>
    <head>
        <meta name="author" content="Djordje Danicic 2017/0692">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">  
                @if(session()->has('korisnik'))
                    {{$korisnik->ime}} {{$korisnik->prezime}} <br> Bodovi: {{$korisnik->bodovi}} <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button>
                @else
                    <button onclick="window.location.href = '/reg_log';">Registruj/Uloguj se</button>
                @endif
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan="3">
                    @if(session()->has('korisnik'))
                        <button onclick="window.location.href = '{{ URL::route('pocetna.show',$korisnik->id) }}';">Pocetna</button>
                        <button type="button" onclick="window.location.href ='/mojeNarudz';">Moje Narudzbine</button>
                    @else
                        <button onclick="window.location.href = '/pocetnaGost';">Pocetna</button>
                        <button type="button" onclick="nijeMoguce()">Moje Narudzbine</button>
                    @endif
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <center>
            <table width = "50%" border = "0px">
                <tr>
                    <th colspan = "3">
                        <h3>Moje narudzbine</h3>
                    </th>
                </tr>
                <tr>
                    <th colspan = "3"><br><hr><br></th>
                </tr>
                <tr>
                    <th width = "40%">
                        Naziv
                    </th>
                    <th width = "20%">
                        Kolicina
                    </th>
                    <th width = "40%">
                        Cena
                    </th>
                </tr>
                @if(session()->has('porudzbina'))
                    @foreach($porucena_jela as $poruceno_jelo)
                        <tr>
                            <th width = "40%">
                                {{$poruceno_jelo->naziv_jela}}
                            </th>
                            <th width = "20%">
                                x{{$poruceno_jelo->kvantitet}}
                            </th>
                            <th width = "40%">
                                {{$poruceno_jelo->cena_jela*$poruceno_jelo->kvantitet}} rsd
                            </th>
                        </tr>
                    @endforeach
                    <tr>
                        <th colspan = "3"><br> <hr> </th>
                    </tr>
                    <tr>
                        <th colspan = "3">
                            <h3>Ukupna cena</h3>
                        </th>
                    </tr>
                    <form action="/bez_pop" method = 'get'>
                    @csrf
                    <tr>
                        <th>
                            Bez popusta
                        </th>
                        <th>
                            <h3 name = 'cena_bez_pop'>{{$porudzbina->cena_bez_pop}} rsd</h3>
                        </th>
                        <th>
                            <button type = "submit">Poruci</button>
                        </th>
                    </tr>
                    </form>
                    <form action = "/sa_pop"  method = 'get'>
                    @csrf
                    <tr>
                        <th>
                            Sa popustom
                        </th>
                        <th>
                            <h3 name = 'cena_sa_pop'>{{$porudzbina->cena_sa_pop}} rsd</h3>
                        </th>
                        <th>
                            <button type = "submit">Poruci</button>
                        </th>
                    </tr>
                    </form>
                @endif
            </table>
        </center>

    </body>
</html>