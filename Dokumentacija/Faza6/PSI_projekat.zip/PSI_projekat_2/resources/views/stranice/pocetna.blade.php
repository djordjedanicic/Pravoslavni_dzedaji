
<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 2017/0698">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">  
                @if(session()->has('korisnik'))
                    {{$korisnik->ime}} {{$korisnik->prezime}} <br> Bodovi: {{$korisnik->bodovi}} <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button>
                @else
                    <button onclick="window.location.href = '/reg_log';">Registruj/Uloguj se</button>
                @endif
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan="3">
                    @if(session()->has('korisnik'))
                        <button onclick="window.location.href = '{{ URL::route('pocetna.show',$korisnik->id) }}';">Pocetna</button>
                        <button type="button" onclick="window.location.href ='/mojeNarudz';">Moje Narudzbine</button>
                    @else
                        <button onclick="window.location.href = '/pocetnaGost';">Pocetna</button>
                        <button type="button" onclick="nijeMoguce()">Moje Narudzbine</button>
                    @endif
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table width = "100%" border = "0px">
            <tr>
                <th colspan = "2" align = "left">Filteri:</th>
            </tr>
            <tr>
                <form method="GET" action="{{ URL::route('pocetna.filter.show')}}" name="forma_filter">
                @csrf
                    <th align = "left" width = "15%" valign="top">
                    <i>Lokacija</i><br>
                        <ul>
                            <li>
                                <input type="checkbox" id="noviBeograd" name="opstina[]" value="Novi Beograd">
                                <label for="noviBeograd"> Novi Beograd</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="stariGrad" name="opstina[]" value="Stari grad">
                                <label for="stariGrad"> Stari grad</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="vracar" name="opstina[]" value="Vracar">
                                <label for="vracar"> Vracar</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="vozdovac" name="opstina[]" value="Vozdovac">
                                <label for="vozdovac"> Vozdovac</label><br>
                            </li>
                        </ul><br>
                        <i>Tip Kuhinje</i><br>
                        <ul>
                            <li>
                                <input type="checkbox" id="azijska" name="hrana[]" value="Azijska">
                                <label for="azijska"> Azijska</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="italijanska" name="hrana[]" value="Italijanska">
                                <label for="italijanska"> Italijanska</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="brzaHrana" name="hrana[]" value="Brza hrana">
                                <label for="brzaHrana"> Brza hrana</label><br>
                            </li>
                            <li>
                                <input type="checkbox" id="meksicka" name="hrana[]" value="Meksicka">
                                <label for="meksicka"> Meksicka</label><br>
                            </li>
                        </ul><br>
                    <input type="submit" value="Potvrdi">
                    </th>
                </form>
                <th align = "left" width = "15%" valign="top">
                    &nbsp;
                </th>
                <th width = "70%">
                    <form  method="get" action="/menicontroller" name="forma_meni">
                    @csrf
                    <table>
                        @foreach($restorani as $element)
                            <tr>
                                <th>
                                    <img src= '/images/{{$element->slika}}' width='200' height = '200'>
                                </th>
                                <th align = 'left'>
                                    <ul>
                                        <li>Naziv: {{$element->naziv}}</li>
                                        <li>Adresa: {{$element->lokacija}}</li>
                                        <li>Opstina: {{$element->opstina}}</li>
                                        <li>Tip Kuhinje: {{$element->tip}}</li>
                                        <li>Ocena: {{$element->ocena}}</li>
                                        <li>Radno vreme: {{$element->vreme_od}} - {{$element->vreme_do}}</li>
                                        <li><button name='id_rest' type='submit' value = '{{$element->id}}'>Meni</button></li>
                                    </ul>
                                </th>
                            </tr>
                            <tr></tr>
                                <th width = '100%' colspan = '2'>
                                    <br><hr><br>
                                </th>
                            </tr>
                        @endforeach
                    </table>
                    </form>
                    &nbsp;
                </th>
            </tr>
        </table>
    </body>
</html>
<script>
    function nijeMoguce(){
        alert("Niste ulogovani, nemate pristup ovoj opciji");
    }
</script>