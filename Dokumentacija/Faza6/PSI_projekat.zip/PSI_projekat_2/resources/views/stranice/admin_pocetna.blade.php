<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 0698/2017">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Korisnik: <u>ADMIN</u> <br><button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table width = "100%">
            <tr>
                <th align = "left" style = "color:red">Korisnici:</th>
                <th align = "left" style = "color:red">Restorani:</th>
                <th align = "left" style = "color:red">Porudzbine:</th>
            </tr>
                <th width = "100%" colspan = "3">
                    <hr>
                </th>
            <tr>
            <form  method="get" action="/brisanjeKorisnika">
                <th width = "33%" valign = "top">
                    <table width = "100%">
                    @foreach($korisnici as $korisnik)
                    <tr>
                        <th align = "left" width = "50%">
                        {{$korisnik->ime}} {{$korisnik->prezime}} 
                        </th>
                        <th align = "left" width = "50%">
                        <button name='id_kor' type='submit' value = '{{$korisnik->id}}'>Obrisi</button>
                        </th>
                    </tr>
                    @endforeach
                    </table>
                </th>
            </form>
            <form  method="get" action="/brisanjeRestorana">
                <th width = "33%" valign = "top">
                    <table width = "100%">
                    @foreach($restorani as $restoran)
                    <tr>
                        <th align = "left" width = "50%">
                            {{$restoran->naziv}} 
                        </th>
                        <th align = "left" width = "50%">
                            <button name='id_rest' type='submit' value = '{{$restoran->id}}'>Obrisi</button>
                        </th>
                    </tr>
                    @endforeach
                    </table>
                </th>
            </form>
                <th width = "33%" valign = "top">
                
                    <form action="/ukl_vidi_porudz" method = "get">
                    <table width = "100%">
                    @foreach($porudzbine as $porudzbina)
                        <tr>
                            <th align = "left" >
                                    {{$porudzbina->adresa}} - 
                                @if($porudzbina->cena_sa_pop == null)
                                    {{$porudzbina->cena_bez_pop}}rsd
                                @else
                                    {{$porudzbina->cena_sa_pop}}rsd (sa popustom)
                                @endif
                            </th>
                            <th align = "center">
                                <button type = "submit" name = "vidi" value = "{{$porudzbina->id}}">Vidi</button>
                                <button type = "submit" name = "ukloni" value = "{{$porudzbina->id}}">Ukloni</button>
                            </th>
                        </tr>
                    @endforeach
                    </table>
                    </form>
                </th>
            </tr>
        </table>
       

    </body>
</html>