
<form method="post" action="{{ URL::route('update.restoran',session('restoran'))}}" enctype="multipart/form-data" class="form-horizontal">
@csrf
    <input id="profile_image" type="file" name="slika"><br>
    <button type="submit">Potvrdi</button>
</form>