<html>
    <head>
        <meta name="author" content="Slobodan Jevtic 2017/0758">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "50%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
            </tr>
            <tr>
                <th width = "100%" colspan = "2">
                    <br><hr><br>
                </th>
            </tr>
            <form   action="{{ URL::route('update.jelo',$jelo->id)}}" method = "post" enctype="multipart/form-data" class="form-horizontal">
            @csrf
            <tr>
                <th align="right">
                    <h4>Naziv jela:</h4>
                </th>
                <th align="left"  valign = "top">
                    <input type="text" name="naziv" value = "{{$jelo->naziv}}">
                </th>
            </tr>
            <tr>
                <th align="right">
                    <h4>Cena:</h4>
                </th>
                <th align="left"  valign = "top">
                    <input type="text" name="cena" value = "{{$jelo->cena}}">
                </th>
            </tr>
            <tr>
                <th align="right">
                    <h4>Vrsta jela:</h4>
                </th>
                <th align="left"  valign = "top">
                    <input type="text" name="vrsta" value = "{{$jelo->vrsta}}">
                </th>
            </tr>
            <tr>
                <th align="right">
                    <h4>Sastojci:</h4>
                </th>
                <th align="left"  valign = "top">
                    <input type="text" name="sastojci" value = "{{$jelo->sastojci}}">
                </th>
            </tr>
            <tr>
                <th align="right">
                    <h4>Kolicina:</h4>
                </th>
                <th align="left"  valign = "top">
                    <input type="text" name="gramaza" value = "{{$jelo->gramaza}}">
                </th>
            </tr>
            <tr>
                <th align="right">
                    <h4>Slika:</h4>
                </th>
                <th align="left"  valign = "top">
                    <input type="file" name="slika">
                </th>
            </tr>
            <tr>
                <th colspan="2">
                    <button type="submit">Potvrdi</button>
                </th>
            </tr>
            </form>
        </table>
    </body>
</html>