<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/reg_log', function () {
    return view('registracija.logovanje');
});

Route::get('/dodaj_tekst', function () {
    return view('funRegRest.dodaj_text');
});
Route::get('/dodaj_sliku', function () {
    return view('funRegRest.dodaj_sliku');
});

Route::get('reg_korisnika', array('as' => 'reg_korisnika', function()
{
   return view('registracija.reg_korisnika');
}));
Route::get('reg_restorana', array('as' => 'reg_restorana', function()
{
   return view('registracija.reg_restorana');
}));

Route::get('pocetna', array('as' => 'pocetna', function()
{
    return view('stranice.pocetna');
}));
Route::get('restoran', array('as' => 'restoran', function()
{
    return view('stranice.restoran');
}));
Route::get('log_reg', array('as' => 'log_reg', function()
{
   return view('registacija.logovanje');
}));


Route::get('/pocetna/{id}','LogovanjeController@showKorisnikPocetna')->name('pocetna.show');
Route::get('/pocetna_restoran/{id}','LogovanjeController@showRestoranPocetna')->name('pocetna_restoran.show');
Route::get('/admin_pocetna/{id}','LogovanjeController@showAdminPocetna')->name('admin.show');//moe

Route::get('/filtercontroller', "FilterController@formSubmit")->name('pocetna.filter.show');
Route::get('/menicontroller', 'MeniController@formSubmit');
Route::get('/dodaj_u_korpu', 'PorudzbinaController@dodaj_u_korpu');
Route::get('/pocetnaGost', 'LogovanjeController@logout');
Route::get('/mojeNarudz', 'KorisnikController@mojeNarudz');
Route::get('/', 'LogovanjeController@logout');
Route::get('/forma_dodaj_jelo', 'JeloController@prikazDodajJelo');
Route::get('/bez_pop', 'PorudzbinaController@bez_pop');
Route::get('/sa_pop', 'PorudzbinaController@sa_pop');
Route::get('/brisanje_azuriranje_jela', 'JeloController@bris_azur_jela');
Route::get('/ukl_vidi_porudz', 'AdminController@ukl_vidi_porudz');

Route::get('/brisanjeKorisnika', 'AdminController@brisanjeKorisnika');//moe
Route::get('/brisanjeRestorana', 'AdminController@brisanjeRestorana');//moe

Route::post('/azuriraj_jelo/{id}', 'JeloController@update')->name('update.jelo');
Route::post('logovanje', 'LogovanjeController@login');
Route::post('/update/{id}', 'RestoranController@update')->name('update.restoran');
Route::post('dodaj_jelo', 'JeloController@store');
Route::post('poruci_porudzbinu', 'PorudzbinaController@poruci_porudzbinu');
Route::post('/dodaj_kom/{id_rest}', 'KomentarController@store')->name('postavi.komentar');
Route::post('/oceni/{id}', 'RestoranController@oceni')->name('oceni.restoran');

Route::resource('korisnik', 'KorisnikController');
Route::resource('restoran', 'RestoranController');

