<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Restoran extends Model
{
    protected $fillable = ['id', 'naziv', 'telefon', 'lokacija', 'opstina', 'tip', 'vreme_od', 'vreme_do', 'email', 'sifra', 'slika', 'opis', 'ocena'];

    public function jela() 
    {
        return $this->hasMany(Jelo::class)->orderBy('created_at', 'DESC');
    }

    public function komentari() 
    {
        return $this->hasMany(Komentar::class)->orderBy('created_at', 'DESC');
    }

    public function ocene() 
    {
        return $this->hasMany(Ocena::class);
    }
}
