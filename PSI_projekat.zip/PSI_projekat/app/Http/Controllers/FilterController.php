<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\Restoran;

class FilterController extends Controller
{
    public function formSubmit(Request $req){
        
        /*if(session()->has('korisnik')){
            if($id!=session('korisnik'))
                return back();
            else {
                $korisnik = Korisnik::find($id);
                $restorani = Restoran::all();
                return view('stranice.pocetna', compact('korisnik','restorani'));
            }

        }else return back();*/

        
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "projekat_db";
        //create connection
        $conn = mysqli_connect($host, $dbUsername, $dbPassword, $dbname);
        if (mysqli_connect_error()) {
         die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
        } else {
            $niz_opstina = array();
            $niz_hrana = array();

            if(isset($_GET['opstina'])){
                if(in_array('Novi Beograd', $_GET['opstina'])){
                    array_push($niz_opstina,"Novi Beograd");
                }
                if(in_array('Vracar', $_GET['opstina'])){
                    array_push($niz_opstina,"Vracar");
                }
                if(in_array('Vozdovac', $_GET['opstina'])){
                    array_push($niz_opstina,"Vozdovac");
                }
                if(in_array('Stari grad', $_GET['opstina'])){
                    array_push($niz_opstina,"Stari Grad");
                }
                if(!isset($_GET['hrana'])){


                    $j = count($niz_opstina);
                    if($j==4)
                        $restorani = Restoran::orderBy('ocena','desc')->where('opstina',$niz_opstina[0])->orWhere('opstina',$niz_opstina[1])->orWhere('opstina',$niz_opstina[2])->orWhere('opstina',$niz_opstina[3])->get();
                    if($j==3)
                        $restorani = Restoran::orderBy('ocena','desc')->where('opstina',$niz_opstina[0])->orWhere('opstina',$niz_opstina[1])->orWhere('opstina',$niz_opstina[2])->get();
                    if($j==2)
                        $restorani = Restoran::orderBy('ocena','desc')->where('opstina',$niz_opstina[0])->orWhere('opstina',$niz_opstina[1])->get();
                    if($j==1)
                        $restorani = Restoran::orderBy('ocena','desc')->where('opstina',$niz_opstina[0])->get();
                    if(session()->has('korisnik')){
                        $korisnik = Korisnik::find(session('korisnik'));
                        return view('stranice.pocetna', compact('korisnik','restorani'));
                    }
                    return view('stranice.pocetna', compact('restorani'));
                }
            }

            if(isset($_GET['hrana'])){
                if(in_array('Azijska', $_GET['hrana'])){
                    array_push($niz_hrana,"Azijska");
                }
                if(in_array('Italijanska', $_GET['hrana'])){
                    array_push($niz_hrana,"Italijanska");
                }
                if(in_array('Brza hrana', $_GET['hrana'])){
                    array_push($niz_hrana,"Brza Hrana");
                }
                if(in_array('Meksicka', $_GET['hrana'])){
                    array_push($niz_hrana,"Meksicka");
                }
                if(!isset($_GET['opstina'])){
                    $i = count($niz_hrana);
                    if($i==4)
                        $restorani = Restoran::orderBy('ocena','desc')->where('tip',$niz_hrana[0])->orWhere('tip',$niz_hrana[1])->orWhere('tip',$niz_hrana[2])->orWhere('tip',$niz_hrana[3])->get();
                    if($i==3)
                        $restorani = Restoran::orderBy('ocena','desc')->where('tip',$niz_hrana[0])->orWhere('tip',$niz_hrana[1])->orWhere('tip',$niz_hrana[2])->get();
                    if($i==2)
                        $restorani = Restoran::orderBy('ocena','desc')->where('tip',$niz_hrana[0])->orWhere('tip',$niz_hrana[1])->get();
                    if($i==1)
                        $restorani = Restoran::orderBy('ocena','desc')->where('tip',$niz_hrana[0])->get();
                    
                    if(session()->has('korisnik')){
                        $korisnik = Korisnik::find(session('korisnik'));
                        return view('stranice.pocetna', compact('korisnik','restorani'));
                    }
                    return view('stranice.pocetna', compact('restorani'));
                }
            }

            if(isset($_GET['hrana']) && isset($_GET['opstina'])){
                $j = count($niz_opstina);
                $i = count($niz_hrana);
                if($j==1){
                    if($i==1)
                        $restorani = Restoran::orderBy('ocena','desc')->where('tip',$niz_hrana[0])->where('opstina',$niz_opstina[0])->get();
                        //$restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]') and (opstina = '$niz_opstina[0]') ";
                    if($i==2)
                        $restorani = Restoran::orderBy('ocena','desc')->where('tip',$niz_hrana[0])->orWhere('tip',$niz_hrana[1])->where('opstina',$niz_opstina[0])->get();
                        //$restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]') and (opstina = '$niz_opstina[0]') ";
                    if($i==3)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]'or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]') and (opstina = '$niz_opstina[0]') ";
                    if($i==4)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]' or tip = '$niz_hrana[3]') and (opstina = '$niz_opstina[0]') ";
                }
                if($j==2){
                    if($i==1)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]') ";
                    if($i==2)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]') ";
                    if($i==3)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]'or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]') ";
                    if($i==4)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]' or tip = '$niz_hrana[3]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]') ";
                }
                if($j==3){
                    if($i==1)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]') and (opstina = '$niz_opstina[0]'or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]') ";
                    if($i==2)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]') and (opstina = '$niz_opstina[0]'or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]') ";
                    if($i==3)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]'or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]') and (opstina = '$niz_opstina[0]'or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]') ";
                    if($i==4)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]' or tip = '$niz_hrana[3]') and (opstina = '$niz_opstina[0]'or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]') ";
                }
                if($j==4){
                    if($i==1)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]' or opstina = '$niz_opstina[3]') ";
                    if($i==2)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]' or opstina = '$niz_opstina[3]') ";
                    if($i==3)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]'or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]' or opstina = '$niz_opstina[3]') ";
                    if($i==4)
                        $restorani = "SELECT * FROM restorans WHERE (tip = '$niz_hrana[0]' or tip = '$niz_hrana[1]' or tip = '$niz_hrana[2]' or tip = '$niz_hrana[3]') and (opstina = '$niz_opstina[0]' or opstina = '$niz_opstina[1]' or opstina = '$niz_opstina[2]' or opstina = '$niz_opstina[3]') ";
                }
                if(session()->has('korisnik')){
                    $korisnik = Korisnik::find(session('korisnik'));
                    return view('stranice.pocetna', compact('korisnik','restorani'));
                }
                return view('stranice.pocetna', compact('restorani'));
            }
        
        }
    }
}
