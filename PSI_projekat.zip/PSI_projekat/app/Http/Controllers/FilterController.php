<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\Restoran;

class FilterController extends Controller
{
    public function formSubmit(Request $req){
            $niz_opstina = null;
            $niz_hrana = null;
            $restorani = null;

            if(isset($_GET['opstina'])) {
                $niz_opstina = $_GET['opstina'];
            }
            if(isset($_GET['hrana'])) {
                $niz_hrana = $_GET['hrana'];
            }
            if($niz_hrana != null) {
                $restorani = Restoran::orderBy('ocena','desc')->whereIn('tip',$niz_hrana)->get();
            }
            if($niz_opstina != null) {
                if($restorani == null) {
                    $restorani = Restoran::orderBy('ocena','desc')->whereIn('opstina',$niz_opstina)->get();
                }
                else {
                    $restorani = $restorani->intersect(Restoran::orderBy('ocena','desc')->whereIn('opstina',$niz_opstina)->get());
                }
            }
            if($niz_hrana == null && $niz_opstina == null) {
                $restorani = Restoran::orderBy('ocena','desc')->select('*')->get();
            }

            if(session()->has('korisnik')) {
                $korisnik = Korisnik::find(session('korisnik'));
                return view('stranice.pocetna', compact('korisnik','restorani'));
            }
            return view('stranice.pocetna', compact('restorani'));
    }

    
}
