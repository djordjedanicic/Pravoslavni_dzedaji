<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\Restoran;
use App\Porudzbina; 
use App\Komentar;
use App\Ocena;
use App\PorucenoJelo;
class AdminController extends Controller
{
    public function brisanjeKorisnika(Request $req){
        if(session()->has('admin')){

            $kom = Komentar::where('id_kor', $req->id_kor);
            $kom->delete();
            
            $ocene = Ocena::where('korisnik_id', $req->id_kor)->get();
            foreach($ocene as $ocena){
                $idRest = $ocena->restoran_id;
                $ocena->delete();
                $restoran = Restoran::find($idRest);
                $pom = Ocena::where('restoran_id',$idRest)->get();
                if(count($pom)>0)
                    $restoran->ocena = Ocena::where('restoran_id',$idRest)->avg('vrednost');
                else
                    $restoran->ocena = 0;
                $restoran->save();
                
            }   

            $kor = Korisnik::find($req->id_kor);
            $kor->delete();

            return redirect()->route('admin.show',session('admin'));
        }
        else return back();
    }

    public function brisanjeRestorana(Request $req){
        if(session()->has('admin')){

            $kom = Komentar::where('id_rest', $req->id_rest);
            $kom->delete();

            $ocena = Ocena::where('restoran_id', $req->id_rest);
            $ocena->delete();

            $restoran = Restoran::find($req->id_rest);
            $restoran->delete();

            return redirect()->route('admin.show',session('admin'));
        }
        else return back();
    }

    public function ukl_vidi_porudz(Request $req){
        if(session()->has('admin')){
            if($req->has('vidi')){
                $porucena_jela = PorucenoJelo::orderBy('poruceno_jelos.id','asc')
                ->join('jelos', 'jelos.id','=','poruceno_jelos.id_jelo')
                ->select(
                    'jelos.naziv as naziv',
                    'poruceno_jelos.kvantitet as kvantitet',
                    'jelos.cena as cena'
                )
                ->where('id_porudz',$req->vidi)->get();
                foreach($porucena_jela as $poruceno_jelo){
                    echo $poruceno_jelo->naziv . " - x". $poruceno_jelo->kvantitet." - ".$poruceno_jelo->cena*$poruceno_jelo->kvantitet."rsd <br>" ;
                }
            }
            if($req->has('ukloni')){
                $pordzbina = Porudzbina::find($req->ukloni);
                $pordzbina->status = "obradjeno";
                $pordzbina->save();
                return redirect()->route('admin.show',session('admin'));
            }
        } else back();
    }
}
