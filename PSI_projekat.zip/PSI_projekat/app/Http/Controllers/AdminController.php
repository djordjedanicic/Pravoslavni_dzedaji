<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\Restoran;
use App\Porudzbina; 
use App\Komentar;
use App\Ocena;
class AdminController extends Controller
{
    public function brisanjeKorisnika(Request $req){
        if(session()->has('admin')){

            $kom = Komentar::where('id_kor', $req->id_kor);
            $kom->delete();
            
            $ocene = Ocena::where('korisnik_id', $req->id_kor)->get();
            foreach($ocene as $ocena){
                $idRest = $ocena->restoran_id;
                $ocena->delete();
                $restoran = Restoran::find($idRest);
                $pom = Ocena::where('restoran_id',$idRest)->get();
                if(count($pom)>0)
                    $restoran->ocena = Ocena::where('restoran_id',$idRest)->avg('vrednost');
                else
                    $restoran->ocena = 0;
                $restoran->save();
                
            }   

            $kor = Korisnik::find($req->id_kor);
            $kor->delete();

            return redirect()->route('admin.show',session('admin'));
        }
        else return back();
    }

    public function brisanjeRestorana(Request $req){
        if(session()->has('admin')){

            $kom = Komentar::where('id_rest', $req->id_rest);
            $kom->delete();

            $ocena = Ocena::where('restoran_id', $req->id_rest);
            $ocena->delete();

            $restoran = Restoran::find($req->id_rest);
            $restoran->delete();

            return redirect()->route('admin.show',session('admin'));
        }
        else return back();
    }
}
