<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\Jelo;
use App\Porudzbina;
use App\PorucenoJelo;
class PorudzbinaController extends Controller
{
    public function dodaj_u_korpu(Request $req){
        if(session()->has('korisnik')){
            $korisnik = Korisnik::find(session('korisnik'));
            $id_jelo = $req->input('id_jela');
            if(!session()->has('porudzbina')){
                $porudzbina = new Porudzbina;
                $porudzbina->id_kor = session('korisnik');
                $porudzbina->cena_bez_pop = 0;
                $porudzbina->cena_sa_pop = 0;
                $porudzbina->adresa = $korisnik->adresa;
                $porudzbina->nacin_placanja = "kes";
                $porudzbina->status = "u izradi";
                $porudzbina->save();
                session(['porudzbina'=>$porudzbina->id]);
            }else{
                $porudzbina = Porudzbina::find(session('porudzbina'));
            }
            $poruceno_jelo = PorucenoJelo::where('id_jelo',$id_jelo)->where('id_porudz',session('porudzbina'))->get()->first();
            if($poruceno_jelo==null){
                $poruceno_jelo = new PorucenoJelo;
                $poruceno_jelo->id_jelo = $id_jelo;
                $poruceno_jelo->id_porudz = session('porudzbina');
                $poruceno_jelo->kvantitet = 0;
                $poruceno_jelo->save();
            }
            $poruceno_jelo->kvantitet++;
            $jelo = Jelo::find($id_jelo);
            $porudzbina->cena_bez_pop += $jelo->cena;
            $porudzbina->cena_sa_pop = $porudzbina->cena_bez_pop - $korisnik->bodovi;
            $poruceno_jelo->save();
            $porudzbina->save();
        }
        return back();
    }
}
