<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\Restoran;
use App\Jelo;
use App\Komentar;

class LogovanjeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    public function logout(){
        $restorani = Restoran::orderBy('ocena', 'desc')->select('*')->get();
        if(session()->has('korisnik')){
           session()->forget('korisnik');
        }else {
            if(session()->has('restoran')){
                session()->forget('restoran');
            }
        }
        if(session()->has('porudzbina')){
            session()->forget('porudzbina');
        }
        return view('stranice.pocetna', compact('restorani'));
    }

    public function login(Request $request)
    {
        $korisnik = Korisnik::where('email',$request->email)->where('sifra',$request->sifra)->get();
        if(count($korisnik)==1){
            $korisnik = $korisnik->first();
            //$restorani = Restoran::all()->orderBy('ocena', 'desc');
            session(['korisnik'=>$korisnik->id]);
            return redirect()->route('pocetna.show',$korisnik->id);
        }
        $restoran = Restoran::where('email',$request->email)->where('sifra',$request->sifra)->get();
        if(count($restoran)==1){
            $restoran = $restoran->first();
            session(['restoran'=>$restoran->id]);
            return redirect()->route('pocetna_restoran.show',$restoran->id);
            //return view('stranice.restoran',compact('restoran'));
        }
        //jos za admina
        return back();

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showKorisnikPocetna($id)
    {
        if(session()->has('korisnik')){
            if($id!=session('korisnik'))
                return back();
            else {
                $korisnik = Korisnik::find($id);
                $restorani = Restoran::orderBy('ocena', 'desc')->select('*')->get();
                return view('stranice.pocetna', compact('korisnik','restorani'));
            }
        }else return back();
 
    }

    public function showRestoranPocetna($id)
    {
        if(session()->has('restoran')){
            if($id!=session('restoran'))
                return back();
            else {
                $restoran = Restoran::find($id);
                $jela = Jelo::where('id_rest',$id)->get();
                $komentari = Komentar::orderBy('id_rest', 'desc')
                        ->join('korisniks', 'korisniks.id', '=', 'komentars.id_kor')
                        ->select( 
                                 'korisniks.ime as ime',
                                 'korisniks.prezime as prezime',
                                 'komentars.tekst as tekst'
                               )
                        ->where('id_rest',$id)
                        ->get();
                return view('stranice.restoran',compact('restoran','jela','komentari'));
            }
        }else return back();
 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
