<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Restoran;
use App\Korisnik;
use App\Jelo;
use App\Komentar;

class MeniController extends Controller
{
    public function formSubmit(Request $req){
        $id = $req->input('id_rest');
        $restoran = Restoran::where('id',$id)->get();
        $jela = Jelo::where('id_rest',$id)->get();
        $komentari = Komentar::orderBy('id_rest', 'desc')
        ->join('korisniks', 'korisniks.id', '=', 'komentars.id_kor')
        ->select( 
                 'korisniks.ime as ime',
                 'korisniks.prezime as prezime',
                 'komentars.tekst as tekst'
               )
        ->where('id_rest',$id)
        ->get();
        //echo count($restoran);
        $restoran = $restoran->first();
        if(session()->has('korisnik')){
            $korisnik = Korisnik::where('id',session('korisnik'))->get();
            $korisnik = $korisnik->first();
            //echo $restoran;
            //!!!!!!!!!!-----doadati jela u compact-u
            return view('stranice.meni_restorana', compact('restoran','korisnik','jela','komentari'));
        }
        //!!!!!!!!!!-----doadati jela u compact-u
        return view('stranice.meni_restorana', compact('restoran','jela','komentari'));

        //za id_rest naci sve komentare(id_kor,text) sa tim id_restorana
    }
}
