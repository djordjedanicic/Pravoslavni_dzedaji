<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Korisnik;
use App\PorucenoJelo;
use App\Porudzbina;

class KorisnikController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('registracija.reg_korisnika');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function mojeNarudz()
    {
        if(session()->has('korisnik')){
            $korisnik = Korisnik::find(session('korisnik'));
            if(session()->has('porudzbina')){
                $porudzbina = Porudzbina::find(session('porudzbina'));
                $porucena_jela = PorucenoJelo::orderBy('poruceno_jelos.id', 'desc')
                ->join('jelos', 'jelos.id', '=', 'poruceno_jelos.id_jelo')
                ->select(
                         'jelos.naziv as naziv_jela',
                         'poruceno_jelos.kvantitet as kvantitet',
                         'jelos.cena as cena_jela',
                        )
                ->where('id_porudz',$porudzbina->id)
                ->get();
                return view('stranice.moje_narudzbine', compact('korisnik','porucena_jela','porudzbina'));
            }else{
                return view('stranice.moje_narudzbine', compact('korisnik'));
            }
        }else{
            return back();
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $korisnik = new Korisnik;
        $this->validate($request, [
            'ime' => 'required',
            'prezime' => 'required',
            'adresa' => 'required',
            'telefon' => 'required',
            'pol' => 'required',
            'email' => 'required|unique:korisniks|unique:restorans',
            'sifra' => 'required',
        ]);
        $korisnik->ime = $request->ime;
        $korisnik->prezime = $request->prezime;
        $korisnik->adresa = $request->adresa;
        $korisnik->telefon = $request->telefon;
        $korisnik->pol = $request->pol;
        $korisnik->email = $request->email;
        $korisnik->sifra = $request->sifra;
        $korisnik->bodovi = 0.0;
        $korisnik->save();
        return view('registracija.logovanje');
    }




    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
