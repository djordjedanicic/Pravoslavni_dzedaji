<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Restoran;
use App\Ocena;

class RestoranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $restoran = new Restoran;
        $this->validate($request, [
            'naziv' => 'required',
            'opstina' => 'required',
            'lokacija' => 'required',
            'telefon' => 'required',
            'tip' => 'required',
            'vreme_od' => 'required',
            'vreme_do' => 'required',
            'email' => 'required|unique:restorans|unique:korisniks',
            'sifra' => 'required',
        ]);
        $restoran->naziv = $request->naziv;
        $restoran->opstina = $request->opstina;
        $restoran->lokacija = $request->lokacija;
        $restoran->telefon = $request->telefon;
        $restoran->tip = $request->tip;
        $restoran->email = $request->email;
        $restoran->vreme_od = $request->vreme_od;
        $restoran->vreme_do = $request->vreme_do;
        $restoran->sifra = $request->sifra;
        $restoran->ocena = 0.0;
        $restoran->save();
        return view('registracija.logovanje');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $rest = Restoran::find($id);
        $rest->fill($request->all());
        if($request->hasFile('slika')){
            $this->validate($request, [
                'slika' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
            ]);
            $imageName = time().'.'.$request->slika->extension();  
            $request->slika->move(public_path('images'), $imageName);
            $rest->slika = $imageName;
        }
        $rest->save();
        return redirect()->route('pocetna_restoran.show',$id);
    }


    public function oceni(Request $request,$id)
    {
        if(session()->has('korisnik')){
            $this->validate($request, [
                'ocena' => 'required',
            ]);
            //nadji ocenu tog korisnika na taj rest i update je, ako ne tek onda stvori ocenu
            $ocena = Ocena::where('korisnik_id',session('korisnik'))->where('restoran_id', $id)->first();
            echo $ocena;
            if($ocena==null){
                $ocena = new Ocena;
                $ocena->restoran_id = $id;
                $ocena->korisnik_id = session('korisnik');
            }
            if($request->ocena=='ocena_1')
                $ocena->vrednost = 1;
            else {
                if($request->ocena=='ocena_2')
                    $ocena->vrednost = 2;
                else {
                    if($request->ocena=='ocena_3')
                        $ocena->vrednost = 3;
                    else {
                        if($request->ocena=='ocena_4')
                            $ocena->vrednost = 4;
                        else {
                            if($request->ocena=='ocena_5')
                                $ocena->vrednost = 5;
                        }
                    }
                }
            }
            $ocena->save();
            $restoran = Restoran::find($id);
            $restoran->ocena = Ocena::where('restoran_id',$id)->avg('vrednost');
            $restoran->save();
        }
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
