
<?php $__env->startSection('telo'); ?>
    <div class="row">   
        <div class="container col-sm-6 offset-sm-5">
            <div class="row">
                <form method = "post" action = "/restoran">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Naziv</label>
                        <div class="col-sm-9">
                        <input type="text" class="form-control" placeholder="Unesite naziv.." name = "naziv">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class = "col-sm-3"for="sel1">Opstina</label>
                        <div class="col-sm-9">
                            <select class=" form-control" id="opstina" name = "opstina">
                                <option value = "Novi Beograd">Novi Beograd</option>
                                <option value = "Stari grad">Stari grad</option>
                                <option value = "Vracar">Vracar</option>
                                <option value = "Vozdovac">Vozdovac</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Lokacija</label>
                        <div class="col-sm-9">
                        <input type="text" class="form-control" placeholder="Unesite lokaciju.." name = "lokacija">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class = "col-sm-3"for="sel1">Tip kuhinje</label>
                        <div class="col-sm-9">
                            <select class=" form-control" id="tip_kuhinje" name = "tip">
                                <option value = "Azijska">Azijska</option>
                                <option value = "Italijanska">Italijanska</option>
                                <option value = "Brza hrana">Brza hrana</option>
                                <option value = "Meksicka">Meksicka</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Telefon</label>
                        <div class="col-sm-9">
                        <input type="number" class="form-control" placeholder="Unesite telefon.." name = "telefon">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="vreme_od" class="col-sm-3 col-form-label">Vreme od</label>
                        <div class="col-sm-9">
                            <input class="form-control" type="time" id="vreme_od" name="vreme_od">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="vreme_do" class="col-sm-3 col-form-label">Vreme do</label>
                        <div class="col-sm-9">
                            <input class="form-control" type="time" id="vreme_do" name="vreme_do">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9">
                        <input type="email" class="form-control" placeholder="Unesite email.." name = "email">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-3 col-form-label">Sifra</label>
                        <div class="col-sm-9">
                        <input type="password" class="form-control" placeholder="Unesite sifru.." name = "sifra">
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <div class="col-sm-10">
                        <button type="submit" class="btn btn-primary">Potvrdi</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="row">
            <?php if(count($errors)>0): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class = "alert alert-danger">
                    <?php echo e($elem); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('registracija.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\PSI_projekat\resources\views/registracija/reg_restorana.blade.php ENDPATH**/ ?>