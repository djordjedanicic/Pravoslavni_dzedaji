<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 0698/2017">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "<?php echo e(url('images/logo4.png')); ?>" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Korisnik: <u>ADMIN</u> <br><button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table width = "100%">
            <tr>
            <form  method="get" action="/brisanjeKorisnika">
                <th width = "33%">
                    Korisnici:<br><br>
                    <?php $__currentLoopData = $korisnici; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $korisnik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <?php echo e($korisnik->ime); ?> <?php echo e($korisnik->prezime); ?> <button name='id_kor' type='submit' value = '<?php echo e($korisnik->id); ?>'>Obrisi</button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </th>
            </form>
            <form  method="get" action="/brisanjeRestorana">
                <th width = "33%">
                Restorani:<br><br>
                    <?php $__currentLoopData = $restorani; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($restoran->naziv); ?> <button name='id_rest' type='submit' value = '<?php echo e($restoran->id); ?>'>Obrisi</button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </th>
            </form>
                <th width = "33%">
                Porudzbine:<br><br>
                    <?php $__currentLoopData = $porudzbine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $porudzbina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($porudzbina->adresa); ?>

                        <?php if($porudbina->cena_sa_pop == null): ?>
                            <?php echo e($porudzbina->cena_bez_pop); ?>

                        <?php else: ?>
                            <?php echo e($porudbina->cena_sa_pop); ?>

                        <?php endif; ?>
                         <input type = "submit" value = "Obrisi">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </th>
            </tr>
        </table>
       

    </body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\PSI_projekat\resources\views/stranice/admin_pocetna.blade.php ENDPATH**/ ?>