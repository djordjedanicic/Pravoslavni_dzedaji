
<?php $__env->startSection('telo'); ?>
    <div class="container col-sm-2 col-sm-offset-5">
        <div class="row">
            <form method = "post" action = "/logovanje">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email </label>
                    <input type="email" name = "email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Unesite email..">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Sifra</label>
                    <input type="password" name = "sifra" class="form-control" id="exampleInputPassword1" placeholder="Unesite sifru..">
                </div>
                <button type="submit" class="btn btn-success">Uloguj se</button>
            </form>
        </div>
        <br>
        <div class="row">
            <div class = "col-sm-4">Registruj se kao:</div>
            <div class = "col-sm-4">
                <button type="button" class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::route('reg_korisnika')); ?>';">Korisnik</button>
            </div>
            <div class="col-sm-4">
                <button type="button" class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::route('reg_restorana')); ?>';">Restoran</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('registracija.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\PSI_projekat\resources\views/registracija/logovanje.blade.php ENDPATH**/ ?>