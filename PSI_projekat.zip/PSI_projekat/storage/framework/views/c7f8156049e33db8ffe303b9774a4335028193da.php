
<form method="post" action="<?php echo e(URL::route('update.restoran',session('restoran'))); ?>" enctype="multipart/form-data" class="form-horizontal">
<?php echo csrf_field(); ?>
    <input id="profile_image" type="file" name="slika"><br>
    <button type="submit">Potvrdi</button>
</form><?php /**PATH C:\xampp\htdocs\Laravel\PSI_projekat\resources\views/funRegRest/dodaj_sliku.blade.php ENDPATH**/ ?>