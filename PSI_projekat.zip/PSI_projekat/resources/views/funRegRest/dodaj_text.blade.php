<html>
    <head>
        <meta name="author" content="Djordje Danicic 2017/0692">
    </head>
    <body>
            <table border = "0px" width = "100%">
                <tr>
                    <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                    <th align = "left" width = "50%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                </tr>
                <tr>
                    <th width = "100%" colspan = "2">
                        <br><hr><br>
                    </th>
                </tr>
                <form method="post" action="{{ URL::route('update.restoran',session('restoran'))}}">
                @csrf
                <tr>
                    <th align="left" colspan="2">
                        <h4>Unesite tekst:</h4>
                    </th>
                </tr>
                <tr>
                    <th align="left"  valign = "top" colspan="2">
                        <textarea name="opis" rows="6" cols="200" placeholder="Unesite tekst.."></textarea>
                    </th>
                </tr>
                <tr>
                    <th colspan="2">
                        <button type="submit">Potvrdi</button>
                    </th>
                </tr>
                </form>
            </table>
    </body>
</html>