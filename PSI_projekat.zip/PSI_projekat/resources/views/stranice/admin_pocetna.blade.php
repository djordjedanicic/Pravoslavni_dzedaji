<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 0698/2017">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Korisnik: <u>ADMIN</u> <br><button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table width = "100%">
            <tr>
            <form  method="get" action="/brisanjeKorisnika">
                <th width = "33%">
                    Korisnici:<br><br>
                    @foreach($korisnici as $korisnik)
                        <br>
                        {{$korisnik->ime}} {{$korisnik->prezime}} <button name='id_kor' type='submit' value = '{{$korisnik->id}}'>Obrisi</button>
                    @endforeach
                </th>
            </form>
            <form  method="get" action="/brisanjeRestorana">
                <th width = "33%">
                Restorani:<br><br>
                    @foreach($restorani as $restoran)
                        {{$restoran->naziv}} <button name='id_rest' type='submit' value = '{{$restoran->id}}'>Obrisi</button>
                    @endforeach
                </th>
            </form>
                <th width = "33%">
                Porudzbine:<br><br>
                    @foreach($porudzbine as $porudzbina)
                            {{$porudzbina->adresa}}
                        @if($porudbina->cena_sa_pop == null)
                            {{$porudzbina->cena_bez_pop}}
                        @else
                            {{$porudbina->cena_sa_pop}}
                        @endif
                         <input type = "submit" value = "Obrisi">
                    @endforeach
                </th>
            </tr>
        </table>
       

    </body>
</html>