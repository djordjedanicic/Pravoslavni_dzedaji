
<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 2017/0698">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">  
                @if(session()->has('korisnik'))
                    {{$korisnik->ime}} {{$korisnik->prezime}} <br> Bodovi: {{$korisnik->bodovi}} <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button>
                @else
                    <button onclick="window.location.href = '/reg_log';">Registruj/Uloguj se</button>
                @endif
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan="3">
                    @if(session()->has('korisnik'))
                        <button onclick="window.location.href = '{{ URL::route('pocetna.show',$korisnik->id) }}';">Pocetna</button>
                        <button type="button" onclick="window.location.href ='/mojeNarudz';">Moje Narudzbine</button>
                    @else
                        <button onclick="window.location.href = '/pocetnaGost';">Pocetna</button>
                        <button type="button" onclick="nijeMoguce()">Moje Narudzbine</button>
                    @endif
                </th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
                    <tr>
                        <th width = "30%">
                        <img src = '/images/{{$restoran->slika}}'  width="200" height = "200">
                        </th>
                        <th align="left">
                            <h4>
                                {{$restoran->opis}}
                            </h4>
                        </th>
                    </tr>
                    <tr>
                        <th colspan = "2">
                            <br><hr><br>
                        </th>
                    </tr>
                    <tr>
                        <form action="{{ URL::route('oceni.restoran',$restoran->id)}}" method="post">
                        @csrf
                            <th colspan = "2" align = "right"> 
                                <input type="radio" name="ocena" value="1" id="ocena_1"><label for="ocena_1">1</label>
                                <input type="radio" name="ocena" value="2" id="ocena_2"><label for="ocena_2">2</label>
                                <input type="radio" name="ocena" value="3" id="ocena_3"><label for="ocena_3">3</label>
                                <input type="radio" name="ocena" value="4" id="ocena_4"><label for="ocena_4">4</label>
                                <input type="radio" name="ocena" value="5" id="ocena_5"><label for="ocena_5">5</label>
                                &nbsp;
                                @if(session()->has('korisnik'))
                                    <input type="submit" value="Oceni">
                                @else
                                    <input type="button" value="Oceni" onclick="nijeMoguce()">
                                @endif
                            </th>
                        </form>
                    </tr>
                    <tr>
                        <th align="center" colspan = "2">
                            <h2>Meni {{$restoran->naziv}}</h2>
                        </th>
                    </tr>
                    <tr>
                        <th>&nbsp;</th>
                        <th width = "75%">
                            <form  method="get" action="/dodaj_u_korpu" name="forma_meni">
                            @csrf
                            <table>
                                @foreach($jela as $jelo)
                                <tr>
                                    <th>
                                        <img src = '/images/{{$jelo->slika}}' width='200' height = '200'>
                                    </th>
                                    <th align = 'left'>
                                        <ul style="list-style-type:none;">
                                            <li>Naziv: {{$jelo->naziv}}</li>
                                            <li>Cena: RSD {{$jelo->cena}}</li>
                                            <li>Vrsta Jela: {{$jelo->vrsta}}</li>
                                            <li>Sastojci: {{$jelo->sastojci}}</li>
                                            <li>Kolicina: {{$jelo->gramaza}}g</li>
                                            <br>
                                            <li><button type="submit" name = "id_jela" value = "{{$jelo->id}}">Dodaj u korpu</button></li>
                                        </ul>
                                    </th>
                                </tr>
                                <tr>
                                    <th width = '100%' colspan = '2'>
                                        <br><hr><br>
                                    </th>
                                </tr>
                                @endforeach
                            </table>
                            </form>
                        </th>
                    </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
        <table border="0px" width = "100%">
            <form action="{{ URL::route('postavi.komentar',$restoran->id)}}" method="post">
            @csrf
            <tr>
                <th align="left" colspan="2">
                    <h4>Unesi komentar:</h4>
                </th>
            </tr>
            <tr>
                <th align="left"width = "70%">
                    <input type="text" name="tekst_kom" size="200">
                </th>
                <th align="left">
                    @if(session()->has('korisnik'))
                        <input type="submit" value="Postavi">
                    @else
                        <input type="button" value="Postavi" onclick="nijeMoguce()">
                    @endif
                </th>
            </tr>
            </form>
            <table border="0px" width = "100%">
                <tr>
                    <th width = "5%">
                        &nbsp;
                    </th>
                    <th>
                        <table>
                            @foreach($komentari as $kom)
                                <tr>
                                    <th width = "5%" align="left">
                                        <img src = "slike/user_logo.png" width="40" height = "40">
                                    </th>
                                    <th align="left">
                                        <h5>{{$kom->ime}} {{$kom->prezime}}</h5>
                                    </th>
                                </tr>
                                <tr align="left">
                                    <th colspan="2">
                                        <h5>{{$kom->tekst}}</h5>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="2">
                                        <br><hr><br>
                                    </th>
                                </tr>   
                            @endforeach
                        </table>
                    </th>
                </tr>
            </table>
        </table>
    </body>
</html>
<script>
    function nijeMoguce(){
        alert("Niste ulogovani, nemate pristup ovoj opciji");
    }
</script>