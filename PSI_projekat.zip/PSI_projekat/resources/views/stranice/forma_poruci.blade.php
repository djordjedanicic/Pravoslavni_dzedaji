<html>
    <head>
        <meta name="author" content="Dimitrije Gucevic 2017/0698">
    </head>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "50%"><img src = "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
            </tr>
            <tr>
                <th width = "100%" colspan = "2">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <form action="poruci_porudzbinu" method = 'post'>
        @csrf
            <table border = "0px">
                <tr>
                    <th align = "left">
                        Adresa:
                    </th>
                    <th>
                        <input type="text" name="adresa" size="30" value = "{{$korisnik->adresa}}" >
                    </th>
                </tr>
                <tr>
                    <th align = "left">Nacin placanja: </th>
                    <th>
                        <input type = "radio" name = "placanje" value = 'kes' checked onclick = "zabrani()">&nbsp;Kes
                        <input type = "radio" name = "placanje" value = 'kartica' onclick = "dozvoli()">&nbsp;Kartica
                    </th>
                </tr>
                <tr>
                    <th align = "left">
                        Broj Kartice: 
                    </th>
                    <th>
                        <input type="text" name="brKartice" size="30" id="br_kartice" disabled>
                    </th>
                </tr>
                <tr>
                    <th colspan = "2">
                        <br>
                        <input type = "submit" value = "Potvrdi">
                    </th>
                </tr>
            </table>
        </form>
    </body>
</html>
<script>
    function dozvoli(){
        document.getElementById('br_kartice').disabled = false;
    }
    function zabrani(){
        document.getElementById('br_kartice').disabled = true;
    }
</script>