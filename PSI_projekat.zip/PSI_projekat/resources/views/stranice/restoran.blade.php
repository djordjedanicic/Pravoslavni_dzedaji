<html>
    <head>
        <meta name="author" content="Slobodan Jevtic 2017/0758">
    </head>
	<script>
		function brisanje(){
			alert("da li ste sigurni?");
		}
	</script>
    <body>
        <table border = "0px" width = "100%">
            <tr>
                <th align = "right" width = "50%"><font size = "10">Hotty</font></th>
                <th align = "left" width = "25%"><img src =  "{{url('images/logo4.png')}}" height = "100" width = "100" ></th> 
                <th align = "right" width = "25%" valign = "top">Restoran: <u>{{$restoran->naziv}}</u> <br> <button onclick="window.location.href ='/pocetnaGost';">Odjavi se</button></th>
            </tr>
            <tr>
                <th width = "100%" colspan = "3">
                    <br><hr><br>
                </th>
            </tr>
        </table>
        <table border="0px" width = "100%">
            <tr>
                <th>
                    <img src = "/images/{{$restoran->slika}}" width="200" height = "200">
                </th>
                <th align="left">
                    <h4>
                        {{$restoran->opis}}
                    </h4>
                </th>
            </tr>
            <tr>
                <th >
                <button onclick="window.location.href ='/dodaj_sliku';">Promeni logo</button>
                </th>
                <th align="right">
                    <button onclick="window.location.href ='/dodaj_tekst';">Promeni tekst</button>
                </th>
            </tr>
            <th width = "100%" colspan = "2">
                 <br><hr><br>
            </th>
            <tr>
                <th align="center" colspan = "2">
                    <h2>Meni {{$restoran->naziv}}</h2>
                </th>
            </tr>
            <tr>
                <th valign = "top">
                    <button onclick="window.location.href ='/forma_dodaj_jelo';">Dodaj jelo</button>
                </th>
                <th width = "75%">
                    <table>
                         @foreach($jela as $jelo)
                                <tr>
                                    <th>
                                        <img src= '/images/{{$jelo->slika}}' width='200' height = '200'>
                                    </th>
                                    <th align = 'left'>
                                        <ul style="list-style-type:none;">
                                            <li>Naziv: {{$jelo->naziv}}</li>
                                            <li>Cena: RSD {{$jelo->cena}}</li>
                                            <li>Vrsta Jela: {{$jelo->vrsta}}</li>
                                            <li>Sastojci: {{$jelo->sastojci}}</li>
                                            <li>Kolicina:{{$jelo->gramaza}}g</li>
                                            <br>
                                            <li><button name='ukloni_jelo' type='submit' value = '{{$jelo->id}}'>Ukloni jelo</button> <button name='azuriraj_jelo' type='submit' value = '{{$jelo->id}}'>Azuriraj</button></li>
                                        </ul>
                                    </th>
                                </tr>
                                <tr>
                                    <th width = '100%' colspan = '2'>
                                        <br><hr><br>
                                    </th>
                                </tr>
                        @endforeach
                    </table>
                </th>
            </tr>
        </table>
        <tr>
            <th width = "100%">
                <br><hr><br>
            </th>
        </tr>
        <tr>
            <th align="left">
                <h3>Komentari</h3>
            </th>
        </tr>
            <table border="0px" width = "100%">
                <tr>
                    <th width = "5%">
                        &nbsp;
                    </th>
                    <th>
                        <table>
                            @foreach($komentari as $kom)
                                <tr>
                                    <th width = "5%" align="left">
                                        <img src = "slike/user_logo.png" width="40" height = "40">
                                    </th>
                                    <th align="left">
                                        <h5>{{$kom->ime}} {{$kom->prezime}}</h5>
                                    </th>
                                </tr>
                                <tr align="left">
                                    <th colspan="2">
                                        <h5>{{$kom->tekst}}</h5>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="2">
                                        <br><hr><br>
                                    </th>
                                </tr>   
                            @endforeach
                        </table>
                    </th>
                </tr>
        </table>
    </body>
</html>