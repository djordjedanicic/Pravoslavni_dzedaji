<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePorucenoJelosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('poruceno_jelos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('id_jelo');
            $table->unsignedBigInteger('id_porudz');
            $table->integer('kvantitet');
            $table->timestamps();

            $table->index('id_jelo');
            $table->index('id_porudz');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('poruceno_jelos');
    }
}
